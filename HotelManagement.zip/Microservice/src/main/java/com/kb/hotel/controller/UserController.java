package com.kb.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kb.hotel.entities.User;
import com.kb.hotel.repository.UserRepo;
import com.kb.hotel.services.UserService;

@RestController("/api")
public class UserController {
	
	@Autowired
	UserRepo userRep;
	
	@Autowired
	UserService userService;
	@PostMapping("/user")
	public ResponseEntity<User> addUser(@RequestBody User user){
		
		return ResponseEntity.created(null).createUser(user);
	}

}
