package com.kb.hotel.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.kb.hotel.payload.ApiResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {

	ResponseEntity<ApiResponse> globalCustomException(){
		
	}

}
